<?php

namespace Cache;

interface CacheAdapaterInterface
{
}
