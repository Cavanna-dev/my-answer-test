<?php

namespace Cache;

use Psr\SimpleCache\InvalidArgumentException;

class InvalidArgumentException extends \Exception implements InvalidArgumentException
{
}
